﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NumberConvertor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Options_SelectedIndexChanged(object sender, EventArgs e)
        {
       

        }

        private void ConvertBTN_Click(object sender, EventArgs e)
        {
            double inputValue;
            if (!double.TryParse(EnterValue.Text, out inputValue))
            {
                MessageBox.Show("Please enter a valid number.");
                return;
            }

            string selectedConversion = Options.SelectedItem.ToString();
            double result = 0;

            switch (selectedConversion)
            {
                case "Centimeters to Inches":
                    result = inputValue / 2.54;
                    break;
                case "Inches to Centimeters":
                    result = inputValue * 2.54;
                    break;
                case "Kilograms to Pounds":
                    result = inputValue * 2.20462;
                    break;
                case "Pounds to Kilograms":
                    result = inputValue / 2.20462;
                    break;
                case "Celsius to Fahrenheit":
                    result = (inputValue * 9 / 5) + 32;
                    break;
                case "Fahrenheit to Celsius":
                    result = (inputValue - 32) * 5 / 9;
                    break;
                default:
                    MessageBox.Show("Select a valid conversion type.");
                    return;
            }

            Output.Text = result.ToString("F4"); 

        }

        private void ClearBTN_Click(object sender, EventArgs e)
        {
            EnterValue.Clear();
            Output.Clear();
            Options.SelectedIndex = 0;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void EnterValue_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
