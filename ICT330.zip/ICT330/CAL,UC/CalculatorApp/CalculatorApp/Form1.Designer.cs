﻿namespace CalculatorApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.n1 = new System.Windows.Forms.Button();
            this.n2 = new System.Windows.Forms.Button();
            this.n3 = new System.Windows.Forms.Button();
            this.badd = new System.Windows.Forms.Button();
            this.n4 = new System.Windows.Forms.Button();
            this.n7 = new System.Windows.Forms.Button();
            this.n5 = new System.Windows.Forms.Button();
            this.n6 = new System.Windows.Forms.Button();
            this.bsub = new System.Windows.Forms.Button();
            this.n8 = new System.Windows.Forms.Button();
            this.n9 = new System.Windows.Forms.Button();
            this.bmul = new System.Windows.Forms.Button();
            this.bequal = new System.Windows.Forms.Button();
            this.bdot = new System.Windows.Forms.Button();
            this.n0 = new System.Windows.Forms.Button();
            this.bc = new System.Windows.Forms.Button();
            this.bdiv = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(0, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(219, 31);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // n1
            // 
            this.n1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.n1.Location = new System.Drawing.Point(12, 66);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(34, 31);
            this.n1.TabIndex = 1;
            this.n1.Text = "1";
            this.n1.UseVisualStyleBackColor = false;
            this.n1.Click += new System.EventHandler(this.btn_click);
            // 
            // n2
            // 
            this.n2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.n2.Location = new System.Drawing.Point(68, 66);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(34, 31);
            this.n2.TabIndex = 2;
            this.n2.Text = "2";
            this.n2.UseVisualStyleBackColor = false;
            this.n2.Click += new System.EventHandler(this.btn_click);
            // 
            // n3
            // 
            this.n3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.n3.Location = new System.Drawing.Point(121, 66);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(34, 31);
            this.n3.TabIndex = 3;
            this.n3.Text = "3";
            this.n3.UseVisualStyleBackColor = false;
            this.n3.Click += new System.EventHandler(this.btn_click);
            // 
            // badd
            // 
            this.badd.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.badd.Location = new System.Drawing.Point(173, 66);
            this.badd.Name = "badd";
            this.badd.Size = new System.Drawing.Size(34, 31);
            this.badd.TabIndex = 4;
            this.badd.Text = "+";
            this.badd.UseVisualStyleBackColor = false;
            this.badd.Click += new System.EventHandler(this.operator_click);
            // 
            // n4
            // 
            this.n4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.n4.Location = new System.Drawing.Point(12, 126);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(34, 31);
            this.n4.TabIndex = 5;
            this.n4.Text = "4";
            this.n4.UseVisualStyleBackColor = false;
            this.n4.Click += new System.EventHandler(this.btn_click);
            // 
            // n7
            // 
            this.n7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.n7.Location = new System.Drawing.Point(12, 181);
            this.n7.Name = "n7";
            this.n7.Size = new System.Drawing.Size(34, 31);
            this.n7.TabIndex = 6;
            this.n7.Text = "7";
            this.n7.UseVisualStyleBackColor = false;
            this.n7.Click += new System.EventHandler(this.btn_click);
            // 
            // n5
            // 
            this.n5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.n5.Location = new System.Drawing.Point(68, 126);
            this.n5.Name = "n5";
            this.n5.Size = new System.Drawing.Size(34, 31);
            this.n5.TabIndex = 7;
            this.n5.Text = "5";
            this.n5.UseVisualStyleBackColor = false;
            this.n5.Click += new System.EventHandler(this.btn_click);
            // 
            // n6
            // 
            this.n6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.n6.Location = new System.Drawing.Point(121, 126);
            this.n6.Name = "n6";
            this.n6.Size = new System.Drawing.Size(34, 31);
            this.n6.TabIndex = 8;
            this.n6.Text = "6";
            this.n6.UseVisualStyleBackColor = false;
            this.n6.Click += new System.EventHandler(this.btn_click);
            // 
            // bsub
            // 
            this.bsub.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.bsub.Location = new System.Drawing.Point(173, 126);
            this.bsub.Name = "bsub";
            this.bsub.Size = new System.Drawing.Size(34, 31);
            this.bsub.TabIndex = 9;
            this.bsub.Text = "-";
            this.bsub.UseVisualStyleBackColor = false;
            this.bsub.Click += new System.EventHandler(this.operator_click);
            // 
            // n8
            // 
            this.n8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.n8.Location = new System.Drawing.Point(68, 181);
            this.n8.Name = "n8";
            this.n8.Size = new System.Drawing.Size(34, 31);
            this.n8.TabIndex = 10;
            this.n8.Text = "8";
            this.n8.UseVisualStyleBackColor = false;
            this.n8.Click += new System.EventHandler(this.btn_click);
            // 
            // n9
            // 
            this.n9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.n9.Location = new System.Drawing.Point(121, 181);
            this.n9.Name = "n9";
            this.n9.Size = new System.Drawing.Size(34, 31);
            this.n9.TabIndex = 11;
            this.n9.Text = "9";
            this.n9.UseVisualStyleBackColor = false;
            this.n9.Click += new System.EventHandler(this.btn_click);
            // 
            // bmul
            // 
            this.bmul.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.bmul.Location = new System.Drawing.Point(173, 181);
            this.bmul.Name = "bmul";
            this.bmul.Size = new System.Drawing.Size(34, 31);
            this.bmul.TabIndex = 12;
            this.bmul.Text = "*";
            this.bmul.UseVisualStyleBackColor = false;
            this.bmul.Click += new System.EventHandler(this.operator_click);
            // 
            // bequal
            // 
            this.bequal.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.bequal.Location = new System.Drawing.Point(51, 285);
            this.bequal.Name = "bequal";
            this.bequal.Size = new System.Drawing.Size(119, 31);
            this.bequal.TabIndex = 13;
            this.bequal.Text = "=";
            this.bequal.UseVisualStyleBackColor = false;
            this.bequal.Click += new System.EventHandler(this.bequal_Click);
            // 
            // bdot
            // 
            this.bdot.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.bdot.Location = new System.Drawing.Point(12, 233);
            this.bdot.Name = "bdot";
            this.bdot.Size = new System.Drawing.Size(34, 31);
            this.bdot.TabIndex = 14;
            this.bdot.Text = ".";
            this.bdot.UseVisualStyleBackColor = false;
            this.bdot.Click += new System.EventHandler(this.bdot_Click);
            // 
            // n0
            // 
            this.n0.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.n0.Location = new System.Drawing.Point(68, 233);
            this.n0.Name = "n0";
            this.n0.Size = new System.Drawing.Size(34, 31);
            this.n0.TabIndex = 15;
            this.n0.Text = "0";
            this.n0.UseVisualStyleBackColor = false;
            this.n0.Click += new System.EventHandler(this.btn_click);
            // 
            // bc
            // 
            this.bc.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.bc.Location = new System.Drawing.Point(121, 233);
            this.bc.Name = "bc";
            this.bc.Size = new System.Drawing.Size(34, 31);
            this.bc.TabIndex = 16;
            this.bc.Text = "C";
            this.bc.UseVisualStyleBackColor = false;
            this.bc.Click += new System.EventHandler(this.bc_Click);
            // 
            // bdiv
            // 
            this.bdiv.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.bdiv.Location = new System.Drawing.Point(173, 233);
            this.bdiv.Name = "bdiv";
            this.bdiv.Size = new System.Drawing.Size(34, 31);
            this.bdiv.TabIndex = 17;
            this.bdiv.Text = "/";
            this.bdiv.UseVisualStyleBackColor = false;
            this.bdiv.Click += new System.EventHandler(this.operator_click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(232, 328);
            this.Controls.Add(this.bdiv);
            this.Controls.Add(this.bc);
            this.Controls.Add(this.n0);
            this.Controls.Add(this.bdot);
            this.Controls.Add(this.bequal);
            this.Controls.Add(this.bmul);
            this.Controls.Add(this.n9);
            this.Controls.Add(this.n8);
            this.Controls.Add(this.bsub);
            this.Controls.Add(this.n6);
            this.Controls.Add(this.n5);
            this.Controls.Add(this.n7);
            this.Controls.Add(this.n4);
            this.Controls.Add(this.badd);
            this.Controls.Add(this.n3);
            this.Controls.Add(this.n2);
            this.Controls.Add(this.n1);
            this.Controls.Add(this.textBox1);
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button n1;
        private System.Windows.Forms.Button n2;
        private System.Windows.Forms.Button n3;
        private System.Windows.Forms.Button badd;
        private System.Windows.Forms.Button n4;
        private System.Windows.Forms.Button n7;
        private System.Windows.Forms.Button n5;
        private System.Windows.Forms.Button n6;
        private System.Windows.Forms.Button bsub;
        private System.Windows.Forms.Button n8;
        private System.Windows.Forms.Button n9;
        private System.Windows.Forms.Button bmul;
        private System.Windows.Forms.Button bequal;
        private System.Windows.Forms.Button bdot;
        private System.Windows.Forms.Button n0;
        private System.Windows.Forms.Button bc;
        private System.Windows.Forms.Button bdiv;
    }
}

