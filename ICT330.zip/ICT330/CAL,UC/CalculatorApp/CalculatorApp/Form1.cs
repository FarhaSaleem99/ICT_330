﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorApp
{
    public partial class Form1 : Form
    {
        double value = 0;
        string operation = "";
        bool operatorPressed=false;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void bequal_Click(object sender, EventArgs e)
        {
            switch (operation) {
                case "+":
                    textBox1.Text =(value + double.Parse(textBox1.Text)).ToString();
                    break;
                case "-":
                    textBox1.Text = (value - double.Parse(textBox1.Text)).ToString();
                    break;
                case "*":
                    textBox1.Text = (value * double.Parse(textBox1.Text)).ToString();
                    break;
                case "/":
                    textBox1.Text = (value / double.Parse(textBox1.Text)).ToString();
                    break;
                default:
                    break;

            }
        }

        private void btn_click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" || (operatorPressed)) {
                textBox1.Clear();
                operatorPressed = false;
            }

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + button.Text;
        }

        private void bdot_Click(object sender, EventArgs e)
        {
            if (!textBox1.Text.Contains("."))
            {
                textBox1.Text = textBox1.Text + ".";
            }
        }

        private void bc_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            value = 0;
        }

        private void operator_click(object sender, EventArgs e)
        {
            if (!operatorPressed)
            {
                Button button = (Button)sender;
                operation = button.Text;
                value = double.Parse(textBox1.Text);
                textBox1.Text = operation;
                operatorPressed = true;
            }
        }
    }
}
