﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment_Reminder_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnSetReminder_Click(object sender, EventArgs e)
        {
            string name = txtPatientName.Text.Trim();
            DateTime date = dtpDate.Value.Date;
            DateTime time = dtpTime.Value;
            DateTime fullAppointmentDateTime = date.Add(time.TimeOfDay);

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Please enter the patient's name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        
            string formattedAppointment = $"{name} - {date.ToShortDateString()} - {time.ToShortTimeString()}";
            lstAppointments.Items.Add(formattedAppointment);

      
            if (fullAppointmentDateTime <= DateTime.Now.AddHours(1) && fullAppointmentDateTime > DateTime.Now)
            {
                MessageBox.Show("Reminder: This appointment is within the next hour!", "Upcoming Appointment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void ClearInputs()
        {
            txtPatientName.Clear();
            dtpDate.Value = DateTime.Now;
            dtpTime.Value = DateTime.Now;

            lstAppointments.Items.Clear();

        }
    }

}

