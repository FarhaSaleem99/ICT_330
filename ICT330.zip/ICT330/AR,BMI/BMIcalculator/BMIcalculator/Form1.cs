﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMIcalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //calculate button

            decimal age = numericUpDown1.Value;
            decimal height = numericUpDown2.Value; 
            decimal weight = numericUpDown3.Value; 

            if (height <= 0 || weight <= 0)
            {
                MessageBox.Show("Please enter valid non-zero values for height and weight.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal bmi = weight / (height * height);
            label6.Text = bmi.ToString("0.00");

            
            string category;
            if (bmi < 18.5m)
                category = "Underweight";
            else if (bmi < 25m)
                category = "Normal weight";
            else if (bmi < 30m)
                category = "Overweight";
            else
                category = "Obese";

            label8.Text = category;
        }



        private void button2_Click(object sender, EventArgs e)
        {
            //reset button
            
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0; 
            numericUpDown3.Value = 0; 

            label6.Text = "..."; 
            label8.Text = "..."; 
        }


        private void label6_Click(object sender, EventArgs e)
        {
            //bmi result
        }

        private void label8_Click(object sender, EventArgs e)
        {
            //health category
        }
    }
}
